<style type="text/css">
  .leftpane {
    width: 20%;
    height: 100%;
    float: left;
    border-collapse: collapse;
  }

  .middlepane {
    width: 40%;
    height: 100%;
    float: left;
    border-collapse: collapse;
  }

  .rightpane {
    width: 40%;
    height: 100%;
    position: relative;
    float: right;
    border-collapse: collapse;
  }

  .img-r {
    /*height: 200px; */
    /*width: 200px; */
    /*margin:0 auto;*/
    height: 118px;
    width: 119px;
    margin-top: 0px;
    margin-bottom: 38px;
    margin-left: -14px;
    border-radius: 100px;
    overflow: hidden;
    border: 7px solid #f6f6f6;
  }

  .card-header1 {
    padding: .75rem 1.25rem;
    margin-bottom: 0;
    background-color: #a6a392;
    border-bottom: 1px solid rgba(0, 0, 0, .125);
  }

  .card-header2 {
    padding: .75rem 1.25rem;
    margin-bottom: 0;
    background-color: #fff;
    border-bottom: 1px solid rgba(0, 0, 0, .125);
  }
</style>
<?php $__env->startSection('content'); ?>
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">User Management</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item active" aria-current="page">Following Badge</li>
            </ol>
          </nav>
        </div>
       
      </div>
    </div>
  </div>
</div>
<div class="container-fluid mt--6">
  <!-- Table -->
  <input type="hidden" value="<?php echo e($data->id); ?>" id="user_id">
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-body ">

         <div class="leftpane">
            <div class="img-r">
              <img src="<?php echo e($data->image); ?>" alt="" style="width: 100px;">
            </div>
          </div>
          <div class="middlepane">
            <div class="key_value_box">
              <div class="key_value_box_div">
                <label class="tbl_row labell">Full Name:</label>
                 <span class="tbl_row value userDetailsColor"><?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></span>
              </div>             
              <div class="key_value_box_div">
                <label class="tbl_row labell">Username:</label>
                 <span class="tbl_row value userDetailsColor"><?php echo e($data->username); ?></span>
              </div>             
              <div class="key_value_box_div">
                <label class="tbl_row labell">MOB. NO.:</label>
                 <span class="tbl_row value userDetailsColor"><?php echo e($data->mobile_country_code); ?>-<?php echo e($data->mobile_no); ?></span>
              </div>             
              <div class="key_value_box_div">
                <label class="tbl_row labell">Email:</label>
                 <span class="tbl_row value userDetailsColor"><?php echo e($data->email); ?></span>
              </div>
              <div class="key_value_box_div">
                <label class="tbl_row labell">Gender:</label>
                <span class="tbl_row value userDetailsColor"><?php echo e($data->gender); ?></span>
              </div>
            </div>
          </div>
          <div class="rightpane">
            <div class="key_value_box">
              <div class="key_value_box_div">
                <label class="tbl_row labell">Ethnicity:</label>
                <span class="tbl_row value userDetailsColor"><?php echo e($data->ethnicity); ?></span>
              </div>
              <div class="key_value_box_div">
                <label class="tbl_row labell">DOB:</label>
                 <?php $r_date = date("d/m/Y", strtotime($data->dob));?>
                <span class="tbl_row value userDetailsColor"><?php echo e($r_date); ?></span>
              </div>
              <div class="key_value_box_div">
                <label class="tbl_row labell">Following Department:</label>
                <span class="tbl_row value userDetailsColor">0</span>                
              </div>
              
              <div class="key_value_box_div">
                <label class="tbl_row labell">Following Badge:</label>
                 <span class="tbl_row value userDetailsColor">0</span>
              </div>
              <div class="key_value_box_div">
               
              </div>
              <div class="key_value_box_div">
                <label class="tbl_row labell">Total Reviews:</label>
                 <span class="tbl_row value userDetailsColor">0</span>
              </div>
              <div class="key_value_box_div">
                <label class="tbl_row labell">Reported Reviews:</label>
                 <span class="tbl_row value userDetailsColor">0</span>
              </div>
            </div>
          </div>  


        </div>
          
            <!-- tab-->
          <div class="card-body" style="background-color: #edce46;border-radius: 5px; border: 3px solid #6b6c7d;">
             
              <div class="middlepane" style="float:right">     
                 <a href="<?php echo e(route('UserDetail',['id' => $data->id])); ?>" class="btn btn-success" data-toggle="notify" data-placement="top" data-align="center" data-type="info" data-icon="ni ni-bell-55">Followings</a>
              </div>
              <div class="rightpane">
                  <a href="<?php echo e(route('UserDetailFollowing',['id' => $data->id])); ?>" class="btn btn-info" data-toggle="notify" data-placement="top" data-align="center" data-type="info" data-icon="ni ni-bell-55"> Reviews</a>
              </div>
          </div>
           <div class="card-body" >
             
              <div class="middlepane" style="float:right">     
                 <a  href="<?php echo e(route('UserDetailFollowingBadge',['id' => $data->id])); ?>" class="btn btn-success" data-toggle="notify" data-placement="top" data-align="center" data-type="info" data-icon="ni ni-bell-55">Badge</a>
              </div>
              <div class="rightpane">
                  <a href="<?php echo e(route('UserDetailFollowing',['id' => $data->id])); ?>" class="btn btn-info" data-toggle="notify" data-placement="top" data-align="center" data-type="info" data-icon="ni ni-bell-55"> Department</a>
              </div>
          </div>
        <div class="table-responsive py-4">
          <table class="table table-flush" id="datatable-basic">
            <thead class="thead-light">
              <tr>
                <th>Badge Number</th>
                <th>Department Name</th>
                <th>Number of reviews</th>
                <th>Rating</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>


<div class="modal fade" id="viewUserDetailModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title text-capitalize" id="businessName"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-6">
            <img
              src="https://png.pngtree.com/png-clipart/20190924/original/pngtree-user-vector-avatar-png-image_4830521.jpg"
              alt="" style="width: 300px; height:300px;">
          </div>
          <div class="col-6" id="viewDepartment">


          </div>
        </div>
        
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  $(document).ready(function(){
  var dataTable = $('#datatable-basic').DataTable({
    language: {
      paginate: {
          previous: '<i class="fas fa-angle-left"></i>',
          next:     '<i class="fas fa-angle-right"></i>'
      },
      aria: {
          paginate: {
              previous: 'Previous',
              next:     'Next'
          }
      }
  },
     "searching": true,
     'processing': true,
     'serverSide': true,
     "bFilter": true,
     "bInfo": true,
     "lengthChange": true,
     "bAutoWidth": true, 
     'ajax': {
        'url':"<?php echo e(route('UserDetailFollowingBadgeData')); ?>",
        'data': function(data){
            var user_id = $('#user_id').val();
          data.user_id = user_id;
          //   var search = $('#search').val();
          // data.search = search;
          // var state_id = $('#state_id').val();
          // data.state_id = state_id;
          // var country_id = $('#country_id').val();
          // data.country_id = country_id;
          //  var fromdate = $('#fromdate').val();
          // data.fromdate = fromdate;
          // var todate = $('#todate').val();
          // data.todate = todate;
        }
       },
    'columns': [
      { data: 'badge_number' } ,
        { data: 'department_name' },
        { data: 'reviews' },
        { data: 'rating' },
        { data: 'action' },
    ]
  });
   $('#search_data1').click(function(){
     dataTable.draw();
  });
  $('#search').keyup(function(){
       dataTable.draw();
    });
});
</script>
<script>
  function viewUserDetailModel(id){
    // alert(id);
    $.ajax({
          url: "<?php echo e(route('viewUserDetailModel')); ?>/" + id, 
          type: 'get',
          success: function (response) {
            if(typeof response.departments.image != "undefined"){ 
            $('#userImage').html(`<img
              src="${response.departments.image}"
              alt="" style="width: 300px; height:300px;">`);
          }else{
            $('#userImage').html(` <img
              src="https://png.pngtree.com/png-clipart/20190924/original/pngtree-user-vector-avatar-png-image_4830521.jpg"
              alt="" style="width: 300px; height:300px;">`);
          }
            $('#viewDepartment').html('');
            
            
         let row=` <div class="col">
              <span>Full Name:</span>
              <span>${response.users.first_name+' '+ response.users.last_name}</span>
              <br>
              <span>Posted On:</span>
              <span>${response.created_at.substr(0,10).split('-').reverse().join('/')}</span>
              <br>
              <span>Likes:</span>
              <span>0</span>
              <br>
              <span>Share:</span>
              <span>0</span>
              <br>
              <span>Comments:</span>
              <span>0</span>
              <br>
              <span>Report:</span>
              <span>0</span>
              <br>
              <span>Rating:</span>
              <span>${response.rating}</span>
              <br>
              <span>Review:</span>
              <span></span>
              <br>
            </div>`;
            $('#viewDepartment').append(row)
        $('#viewUserDetailModel').modal('show');
        },
        error: function(err) {
          console.log(err);
        }
      });
      
      }
</script>
<script type="text/javascript">
  function status(id){
       $.ajax({
      url: "<?php echo e(route('delete_post')); ?>",
      type: "get",
      data: {'post_id':id ,'_token': "<?php echo e(csrf_token()); ?>"},
        success: function (data) {
            //alert();
        //  $(".cancel").(function(){
              
//   $(this).parent("tr:first").remove()
// })
           location.reload();// refresh same page
        }
    });
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dash.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/gold_badge/resources/views/user_management/UserDetailFollowingBadge.blade.php ENDPATH**/ ?>