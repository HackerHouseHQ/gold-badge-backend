<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
   <div id="app">
     <div class="container">
       <div class="navbar-header">
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
            <span class="sr-only">Toggle Navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
          </a>
       </div>
       <div class="collapse navbar-collapse" id="app-navbar-collapse">
         <ul class="nav navbar-nav">&nbsp;</ul>
         <ul class="nav navbar-nav navbar-right"><?php if(auth()->guard()->guest()): ?>
          <?php else: ?>
          <li class="dropdown">
           <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
           <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
           </a>
           <ul class="dropdown-menu">
           <li>
             <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout
             </a>
             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

             </form>
            </li>
            </ul>
           </li>
           <?php endif; ?>
         </ul>
       </div>
      </div>
     <?php echo $__env->yieldContent('content'); ?>
    </div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('admin_css/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('admin_css/css/custom.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('admin_css/css/custom_media.css')); ?>">
</body>
</html>
<?php /**PATH /var/www/html/gold_badge/resources/views/layouts/app.blade.php ENDPATH**/ ?>