<footer class="footer pt-0">
  <div class="row align-items-center justify-content-lg-between">
    <div class="col-lg-6">
      <div class="copyright text-center  text-lg-left  text-muted">
        &copy; 2020 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">Gold Badge
        </a>
      </div>
    </div>
    
  </div>
</footer><?php /**PATH /var/www/html/gold_badge/resources/views/admin_dash/footer.blade.php ENDPATH**/ ?>