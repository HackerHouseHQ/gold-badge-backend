<style type="text/css">
  .show {
    margin-left: 31px;
    margin-right: 92px;
  }

  .active2 {
    background: red;
  }

  #status_id {
    padding-right: 67px;
  }

  #country_id {
    padding-right: 67px;
  }

  #state_id {
    padding-right: 67px;
  }

  #city_id {
    padding-right: 67px;
  }

  #sideshow {
    /*background-color: aqua;*/
    margin-left: 637px;
  }
</style>
<?php $__env->startSection('content'); ?>
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Datatables</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item"><a href="#">Tables</a></li>
              <li class="breadcrumb-item active" aria-current="page">Datatables</li>
            </ol>
          </nav>
        </div>


        <div class="col-lg-6 col-5 text-right">
          
          
          <button type="button" class="btn btn-sm btn-neutral" data-toggle="modal" data-target="#badge">
            Add Badge
          </button>
          
        </div>
         <div class="col-3">
            </div>
            <div class="col-3">
            <a href="<?php echo e(route('department')); ?>" class="btn btn-info" data-toggle="notify" data-placement="top"
              data-align="center" data-type="info" data-icon="ni ni-bell-55">Department List</a>
              </div>
              <div class="col-3">
            <a href="<?php echo e(route('badge')); ?>" class="btn btn-success" data-toggle="notify" data-placement="top"
              data-align="center" data-type="success" data-icon="ni ni-bell-55">Badge List</a>
          </div>
          <div class="col-3">
            </div>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid mt--6">
  <!-- Table -->
  <div class="row">
    <div class="col">
      <div class="card">
        <!-- Card header -->
        <div class="card-body">
          <div class="card-header" style="border-bottom: 1px solid #6073e4 ">
            <form action="" id="search_data" class="search_data_row_class">
              <div class='row'>
                <div class='col-4'>
                  <div class="form-group">
                    <select class="form-control" name="status_id" id="status_id">
                      <option value="">status</option>
                      <option value="1">Active</option>
                      <option value="2">Inactive</option>
                    </select>
                  </div>
                </div>
                <div class='col-4'>
                  <?php $countryList = App\Country::get();?>
                  <div class="form-group">
                    <select class="form-control" name="country_id" id="country_id">
                      <option value="">Select Country</option>
                      <?php $__currentLoopData = $countryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counntryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($counntryList->id); ?>"><?php echo e($counntryList->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class='col-4'>
                  <div class="form-group">
                    <select class="form-control" name="state_id" id="state_id">
                      <option value="">Select State</option>
                    </select>
                  </div>
                </div>
                <div class='col-4'>
                  <div class="form-group">
                    <select class="form-control" name="city_id" id="city_id">
                      <option value="">City</option>
                    </select>
                  </div>
                </div>
                <div class='col-5'>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                      </div>
                      <input class="form-control datepicker" placeholder="Select date" type="text" value=""
                        name="fromdate" id="fromdate">
                    </div>
                  </div>
                </div>
                <div class='col-5'>
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                      </div>
                      <input class="form-control datepicker" placeholder="Select date" type="text" value=""
                        name="todate" id="todate">
                    </div>
                  </div>
                </div>
                <input type="hidden" placeholder="Look for user" name="search2" id="search2" class="search_input">
                <div class='col-2'>
                  <button type="button" id="search_data1" class="btn btn-primary apply_btnn">Apply</button>

                </div>
              </div>
            </form>

          </div>
        </div>

        <div class="table-responsive py-4">
          <table class="table table-flush" id="datatable-basic">
            <thead class="thead-light">
              <tr>
                <th>Badge Number</th>
                <th>Department Name</th>
                <th>Badge Rating</th>
                <th>Department Rating</th>
                <th>Registered On</th>
                <th>Action</th>

              </tr>
            </thead>

            <tbody>

            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  
</div>
<div class="modal fade" id="badge" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Badge</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <form class="form-horizontal" action="<?php echo e(route('AddBadge')); ?>" method="GET">
                <?php echo e(csrf_field()); ?>

                <div class="card-body">
                  <?php $departmentName = App\Department::where('status',1)->get(); ?>
                  <div class="form-group row">
                      <select class="form-control select2" required="required" style="width: 100%;" id="department_id" name="department_id">
                      <option value="">Department Name</option>
                      <?php $__currentLoopData = $departmentName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($value->id); ?>"><?php echo e($value->department_name); ?> </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group row">

                    <input type="text" required="required" class="form-control" placeholder="Badge Number" name="badge_number">

                  </div>
                </div>
                

            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer"  style="margin-top: -50px;">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary ">Add</button>
        
      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $(document).ready(function(){
    $("#country_id").change(function(){
        var country_id = $(this).val();
        $.ajax({
            url: '<?php echo e(route('get_state')); ?>',
            type: 'get',
            data: {country_id:country_id},
            dataType: 'json',
            success:function(response){
            var len = response.length;
            $("#state_id").empty();
            $("#state_id").append("<option value=''>Please Select State</option>");

              for( var i = 0; i<len; i++){
                var id = response[i]['id'];
                var name = response[i]['name'];
                $("#state_id").append("<option value='"+id+"'>"+name+"</option>");
              }
            }
        });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#state_id").change(function(){
      // alert('dfshj');
        var state_id = $(this).val();
        // alert(state_id);
        $.ajax({
            url: '<?php echo e(route('get_city')); ?>',
            type: 'get',
            data: {state_id:state_id},
            dataType: 'json',
            success:function(response){
            var len = response.length;
            $("#city_id").empty();
            $("#city_id").append("<option value=''>Please Select City</option>");

              for( var i = 0; i<len; i++){
                var id = response[i]['id'];
                var name = response[i]['name'];
                $("#city_id").append("<option value='"+id+"'>"+name+"</option>");
              }
            }
        });
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
  var dataTable = $('#datatable-basic').DataTable({
    language: {
      searchPlaceholder: "Department Name",
      paginate: {
          previous: '<i class="fas fa-angle-left"></i>',
          next:     '<i class="fas fa-angle-right"></i>'
      },
      aria: {
          paginate: {
              previous: 'Previous',
              next:     'Next'
          }
      }
  },
     "searching": true,
     'processing': true,
     'serverSide': true,
     "bFilter": true,
     "bInfo": true,
     "lengthChange": true,
     "bAutoWidth": true,
     'ajax': {
        'url':"<?php echo e(route('badge_list')); ?>",
       'data': function(data){
            var status_id = $('#status_id').val();
          data.status_id = status_id;
          var state_id = $('#state_id').val();
          data.state_id = state_id;
          var country_id = $('#country_id').val();
          data.country_id = country_id;
          var city_id = $('#city_id').val();
          data.city_id = city_id;
           var fromdate = $('#fromdate').val();
          data.fromdate = fromdate;
          var todate = $('#todate').val();
          data.todate = todate;
          //  var search = $('#search').val();
          // data.search = search;
        }
       },
    'columns': [
        { data: 'badge_name' } ,
        { data: 'department_name' },
        { data: 'badge_rating' },
        { data: 'department_rating' },
        { data: 'registered_on' },
        { data: 'view' },
    ]
  });
  $('#search_data1').click(function(){
     dataTable.draw();
  });
  //  $('#search').keyup(function(){
  //    dataTable.draw();
  // });
});
</script>
<script type="text/javascript">
  function status(id){
       $.ajax({
      url: "<?php echo e(route('badge_status')); ?>",
      type: "post",
      data: {'user_id':id ,'_token': "<?php echo e(csrf_token()); ?>"},
        success: function (data) {
            location.reload();// refresh same page
        }
    });
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dash.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/gold_badge/resources/views/department_managenment/badge.blade.php ENDPATH**/ ?>