<?php $__env->startSection('content'); ?>
<div class="header bg-primary pb-6">
  <div class="container-fluid">
    <div class="header-body">
      <div class="row align-items-center py-4">
        <div class="col-lg-6 col-7">
          <h6 class="h2 text-white d-inline-block mb-0">Manage Data</h6>
          <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i></a></li>
              <li class="breadcrumb-item active" aria-current="page">Report Reason</li>
            </ol>
          </nav>
        </div>


        <div class="col-lg-6 col-5 text-right">
          
          
          <div class="row-lg-6 row-5">
            <a href="<?php echo e(route('countries')); ?>" class="btn btn-sm btn-neutral">Manage Countries</a>
            <a href="<?php echo e(route('ethnicity')); ?>" class="btn btn-sm btn-neutral">Manage Ethnicity</a>
            <a href="<?php echo e(route('gender')); ?>" class="btn btn-sm btn-neutral">Gender</a>
            <a href="<?php echo e(route('report')); ?>" class="btn btn-sm btn-neutral" style="background-color:#fb6340;color:#fff;">Report Reason Type</a>

          </div>
       
          

          
        </div>

      </div>
    </div>
  </div>
</div>
<div class="container-fluid mt--6">
  <!-- Table -->
  <div class="row">
    <div class="col">
      <div class="card">
        <!-- Card header -->

        <div class="card-body">
          <div class="card-header" style="border-bottom: 1px solid #6073e4 ">
              <div class="row">
                <div class="col-3">
                    <button type="button" class="btn btn-default"> <a style="background-color: #e4bd46; color:#fff;font-size: 15px;" href="<?php echo e(route('add_country_page')); ?>" class="btn btn-sm btn-neutral">Add Country +</a></button>
                </div>
                <div class="col-3">
                    <button type="button" class="btn btn-default"> <a style="background-color: #e4bd46;  color:#fff;font-size: 15px;" href="<?php echo e(route('add_state_page')); ?>" class="btn btn-sm btn-neutral">Add State +</a></button>
                </div>

                <div class="col-3">
                 <button type="button" class="btn btn-default"> <a style="background-color: #e4bd46;  color:#fff;font-size: 15px;" href="<?php echo e(route('add_city_page')); ?>" class="btn btn-sm btn-neutral">Add City +</a></button>
                </div>
                <div class="col-3">
                  <button type="button" class="btn btn-default"><a style="background-color: #e4bd46;  color:#fff;font-size: 15px;" href="<?php echo e(route('add_ethnicity_page')); ?>" class="btn btn-sm btn-neutral">Add Ethnicity +</a></button>
                </div>
                <div class="col-3 py-2">
                  <button type="button" class="btn btn-default"><a style="background-color: #fb6340;  color:#fff;font-size: 15px;" href="<?php echo e(route('showAddReportform')); ?>" class="btn btn-sm btn-neutral">Add Reason Type +</a></button>
                </div>
              </div>
              
           

          </div>
        </div>
        <div class="table-responsive py-4">
          <table class="table table-flush" id="datatable-basic">
            <thead class="thead-light">
              <tr>
                <th><span class="tbl_row">Report Reason</span></th>
                <th><span class="tbl_row">Edit</span></th>
                <th><span class="tbl_row">Delete</span></th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><span class='tbl_row_new'><?php echo e($reportData->name); ?></span></td>
                <td><span class='tbl_row_new'> <button class="btn btn-info btn-sm" data-toggle="modal"
                      data-target="#exampleModalCenter" onclick="openModal(<?php echo e($reportData->id); ?>)">
                      Edit</button><span class='tbl_row_new'></td>
                <td><button class="btn btn-danger btn-sm"><a style="color:#fff;" href="<?php echo e(route('DeleteReport',$reportData->id)); ?>">Delete</a></button></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>


<div id="Privacy" class="modal">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title text-capitalize" id="userName"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span
            aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <form action="<?php echo e(route('AddReport')); ?>" method="GET">
                <div>
                  <b>Add New Report Reason Name</b>
                  <input type="text" name="name" placeholder="Enter Name">
                </div>
                <br>
                <button type="submit" class="btn btn-secondary">Save</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title text-capitalize" id="businessName">Edit Report Reason</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <form action="<?php echo e(route('updatReport')); ?>" method="GET">
                <div id="businessDetails">

                </div>
               <div style="text-align: center;margin-top: 23px;">
                <button type="submit" class="btn btn-info">Save</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  function openModal(id) {
      // alert(id);
      $.ajax({
          url: "<?php echo e(route('Show_edit_report')); ?>/" + id, 
          type: 'get',
          success: function (response) {
          // $('#businessName').html(response.genderData);
          
           
              $('#businessDetails').html('');
            let row = `
              
                <b>Report Reason Name</b>
                <input type="hidden" name="id" value = "${response.id}">
                <input type="text" name="name" value = "${response.name}">
              
 
            `;
              $('#businessDetails').append(row);
              // $('#businessDetails').html(row);
          
        },
        error: function(err) {
          console.log(err);
        }
      });
    }
</script>
<script>
  $('#datatable-basic').dataTable( {
    language: {
      searchPlaceholder: "report",
      paginate: {
          previous: '<i class="fas fa-angle-left"></i>',
          next:     '<i class="fas fa-angle-right"></i>'
      },
      aria: {
          paginate: {
              previous: 'Previous',
              next:     'Next'
          }
      }
  },
     "searching": true,
     'processing': true,
     "bFilter": true,
     "bInfo": true,
     "lengthChange": true,
     "bAutoWidth": true
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dash.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/gold_badge/resources/views/manage_data/report.blade.php ENDPATH**/ ?>