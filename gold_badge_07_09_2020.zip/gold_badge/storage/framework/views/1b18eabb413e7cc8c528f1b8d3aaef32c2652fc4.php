<!--
=========================================================
* Argon Dashboard - v1.2.0
=========================================================
* Product Page: https://www.creative-tim.com/product/argon-dashboard


* Copyright  Creative Tim (http://www.creative-tim.com)
* Coded by www.creative-tim.com



=========================================================
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html>


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">
    <title>Argon Dashboard - Free Dashboard for Bootstrap 4</title>
    <!-- Favicon -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_new/assets/vendor/fortawesome/fontawesome-free/css/all.min.css')); ?>"
    type="text/css">
  

   
  <!-- Argon CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin_new/assets/css/argon.css?v=1.2.0')); ?>" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('admin_new/assets/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
 
  <script src="<?php echo e(asset('admin_new/assets/vendor/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>"></script>
  <!-- Page plugins -->
  <link rel="stylesheet"
    href="<?php echo e(asset('admin_new/assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet"
    href="<?php echo e(asset('admin_new/assets/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>">
  <link rel="stylesheet"
    href="<?php echo e(asset('admin_new/assets/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css')); ?>">
  <!-- Google Tag Manager -->
     <!-- summernote -->
   <link rel="stylesheet" href="<?php echo e(asset('admin_new/assets/css/summernote-bs4.css')); ?>">
    <style>
      .navbar-vertical.navbar-expand-xs .navbar-nav > .nav-item > .nav-link.active {
          background: #e2b52dd1 !important;
      }
      </style>
</head>

<body>
    <!-- Sidenav -->
    <?php echo $__env->make('admin_dash.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Main content -->
    <div class="main-content" id="panel">
        <!-- Topnav -->
        <?php echo $__env->make('admin_dash.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Header -->
        <!-- Header -->
        <div class="header bg-primary pb-6">
            <div class="container-fluid">
                <div class="header-body">
                    <div class="row align-items-center py-4">
                        <div class="col-lg-6 col-7">
                            <!-- <h6 class="h2 text-white d-inline-block mb-0">Default</h6> -->
                            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                                    <!-- <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li> -->
                                    <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                                    <!--<li class="breadcrumb-item active" aria-current="page">Default</li>-->
                                </ol>
                            </nav>
                        </div>
                        
                    </div>
                    <!-- Card stats -->
                    <div class="row">
                        <div class="col-xl-3 col-md-6">
                            <div class="card card-stats">
                                <!-- Card body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">Registered Users</h5>
                                            <span class="h2 font-weight-bold mb-0"><?php echo e($UserCount); ?></span>
                                        </div>
<!--                                        <div class="col-auto">
                                            <div
                                                class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                                <i class="ni ni-active-40"></i>
                                            </div>
                                        </div>-->
                                    </div>
<!--                                    <p class="mt-3 mb-0 text-sm">
                                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                        <span class="text-nowrap">Since last month</span>
                                    </p>-->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card card-stats">
                                <!-- Card body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">Guest Login</h5>
                                            <span class="h2 font-weight-bold mb-0">1</span>
                                        </div>
<!--                                        <div class="col-auto">
                                            <div
                                                class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                                <i class="ni ni-chart-pie-35"></i>
                                            </div>
                                        </div>-->
                                    </div>
<!--                                    <p class="mt-3 mb-0 text-sm">
                                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                        <span class="text-nowrap">Since last month</span>
                                    </p>-->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card card-stats">
                                <!-- Card body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">Total Departments</h5>
                                            <span class="h2 font-weight-bold mb-0"><?php echo e($DepartmentCount); ?></span>
                                        </div>
<!--                                        <div class="col-auto">
                                            <div
                                                class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                                <i class="ni ni-money-coins"></i>
                                            </div>
                                        </div>-->
                                    </div>
<!--                                    <p class="mt-3 mb-0 text-sm">
                                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                        <span class="text-nowrap">Since last month</span>
                                    </p>-->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card card-stats">
                                <!-- Card body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">Total badge</h5>
                                            <span class="h2 font-weight-bold mb-0"><?php echo e($BadgeCount); ?></span>
                                        </div>
<!--                                        <div class="col-auto">
                                            <div
                                                class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                                <i class="ni ni-chart-bar-32"></i>
                                            </div>
                                        </div>-->
                                    </div>
<!--                                    <p class="mt-3 mb-0 text-sm">
                                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                        <span class="text-nowrap">Since last month</span>
                                    </p>-->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card card-stats">
                                <!-- Card body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">Total Reviews</h5>
                                            <span class="h2 font-weight-bold mb-0">10</span>
                                        </div>
<!--                                        <div class="col-auto">
                                            <div
                                                class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                                <i class="ni ni-chart-bar-32"></i>
                                            </div>
                                        </div>-->
                                    </div>
<!--                                    <p class="mt-3 mb-0 text-sm">
                                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                        <span class="text-nowrap">Since last month</span>
                                    </p>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--6">
            <div class="row">
                
    <div class="col-xl-12">






        <div class="card">

        <div class="card-body">
     <div class="card-header" style="border-bottom: 1px solid #6073e4 ">
   <form>
   <div class="row">      
      <div class="col-3">
            <div class="form-group">
            <?php $countryList = App\Country::get(); ?>
                    <select class="form-control" name="country_id" id="country_id">
                    <option value="">Country</option>
                    <?php $__currentLoopData = $countryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counntryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($counntryList->id); ?>"><?php echo e($counntryList->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
      </div>
      <div class="col-3">
      <div class="form-group">
                    <select class="form-control" name="state_id" id="state_id">
                    <option value="">Select State</option>
                    </select>
                  </div>
      </div>
      <div class="col-3">
      <div class="form-group">
                    <select class="form-control" name="city_id" id="city_id">
                    <option value="">Select  City</option>
                    </select>
                  </div>
      </div>
      <div class="col-3">
      <div class="form-group">
                    <select class="form-control" name="gender" id="gender">
                    <option value="">Select Gender</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                    </select>
                  </div>
      </div>
      <div class="col-3">
      <div class="form-group">
      <?php $ethnicytyList = App\Ethnicity::get(); ?>
                    <select class="form-control" name="Ethnicity" id="Ethnicity">
                    <option value="">Select Ethnicity</option>
                    <?php $__currentLoopData = $ethnicytyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->ethnicity_name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
      </div>
      <div class="col-3">
      <div class="form-group">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                  </div>
                  <input class="form-control datepicker" placeholder="Select date form date" type="text" value="" name="fromdate" id="fromdate">
                </div>
              </div>
      </div>
      <div class="col-3">
      <div class="form-group">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                  </div>
                  <input class="form-control datepicker" placeholder="Select date to date" type="text" value="" name="todate" id="todate">
                </div>
              </div>      
      </div>
      <div class="col-2">
      <button type="button" id="search_data1" class="btn btn-primary apply_btnn">Apply</button>
  
      </div>
    </div>
   </form>
    
  </div>
        </div>

   <div class="card-header bg-transparent">
                <div class="row align-items-center">
                    <div class="col">
                        <!-- <h6 class="text-uppercase text-muted ls-1 mb-1">Performance</h6> -->
                        <h5 class="h3 mb-0">Total users</h5>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <!-- Chart -->
                <div class="chart">
                    <canvas id="chart-bars" class="chart-canvas"></canvas>
                </div>
            </div>
        </div>
    </div>
    </div>
    
    <!-- Footer -->

    
    </div>
    </div>

    <!-- Argon Scripts -->
    <!-- Core -->
    <script src="<?php echo e(asset('admin_new/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_new/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_new/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_new/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_new/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>

     <!-- Datepicker -->
   <script src="http://localhost/gold_badge/public/admin_new/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <!-- Optional JS -->
    <script src="<?php echo e(asset('admin_new/assets/vendor/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_new/assets/vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
    <!-- Argon JS -->
    <script src="<?php echo e(asset('admin_new/assets/js/argon.js?v=1.2.0')); ?>"></script>


    <script type="text/javascript">
    $(document).ready(function () {
        $("#country_id").change(function(){
        var country_id = $(this).val();
                $.ajax({
                url: '<?php echo e(route('get_state')); ?>',
                        type: 'get',
                        data: {country_id:country_id},
                        dataType: 'json',
                        success:function(response){
                        var len = response.length;
                                $("#state_id").empty();
                                $("#state_id").append("<option value=''>Please Select</option>");
                                for (var i = 0; i < len; i++){
                        var id = response[i]['id'];
                                var name = response[i]['name'];
                                $("#state_id").append("<option value='" + id + "'>" + name + "</option>");
                        }
                        }
                });
        });
        }
        );
</script>
<script type="text/javascript">
        $(document).ready(function () {
            $("#state_id").change(function(){
            // alert('dfshj');
            var state_id = $(this).val();
                    // alert(state_id);
                    $.ajax({
                    url: '<?php echo e(route('get_city')); ?>',
                            type: 'get',
                            data: {state_id:state_id},
                            dataType: 'json',
                            success:function(response){
                            var len = response.length;
                                    $("#city_id").empty();
                                    $("#city_id").append("<option value=''>Please Select</option>");
                                    for (var i = 0; i < len; i++){
                            var id = response[i]['id'];
                                    var name = response[i]['name'];
                                    $("#city_id").append("<option value='" + id + "'>" + name + "</option>");
                            }
                            }
                    }
                    );
        });
    });
</script>
</body>

</html><?php /**PATH /var/www/html/gold_badge/resources/views/home.blade.php ENDPATH**/ ?>